#!/bin/bash
BOT_TOKEN="7803900933:AAH79fYUg0K0aahn-2fnoywpHEKTzDPO1jE"
CHAT_ID="652800274"
if [ -n "$1" ]; then
    curl -s -X POST "https://api.telegram.org/bot$BOT_TOKEN/sendMessage" -d "chat_id=$CHAT_ID" -d "text=$1" -d "parse_mode=Markdown" > /dev/null 2>&1
fi
