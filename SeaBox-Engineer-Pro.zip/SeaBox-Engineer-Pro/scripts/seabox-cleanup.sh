#!/bin/bash
TOKEN="seabox-agent-2026"
API="http://localhost/api/agent.php"
mysql -u seabox_agent -p'SeaBox2026!Secure' nexusbox_db -e "INSERT IGNORE INTO messages_archive SELECT *, NOW() FROM messages WHERE created_at < NOW() - INTERVAL 1 YEAR; DELETE FROM messages WHERE created_at < NOW() - INTERVAL 1 YEAR; DELETE FROM messages WHERE deleted_at IS NOT NULL AND deleted_at < NOW() - INTERVAL 90 DAY;"
curl -s "$API?action=execute&tool=alert-system&args=%7B%22type%22%3A%22cleanup%22%2C%22severity%22%3A%22info%22%2C%22message%22%3A%22تنظيف%20شهري%20مكتمل%22%7D&approved=true&token=$TOKEN" > /dev/null
echo "$(date): Cleanup completed" >> /home/cboxms0/seabox-cleanup.log
