#!/bin/bash
TOKEN="seabox-agent-2026"
API="http://localhost/api/agent.php"
curl -s "$API?action=execute&tool=check-health-alerts&args=%7B%7D&approved=true&token=$TOKEN" > /dev/null 2>&1
ALERTS=$(mysql -u seabox_agent -p'SeaBox2026!Secure' nexusbox_db -N -e "SELECT COUNT(*) FROM system_alerts WHERE acknowledged=0 AND created_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)")
if [ "$ALERTS" -gt 0 ]; then
    /home/cboxms0/telegram-notify.sh "🚨 *تنبيه SeaBox*\n\nتم اكتشاف $ALERTS مشاكل جديدة"
fi
echo "$(date): Monitor check completed" >> /home/cboxms0/seabox-monitor.log
