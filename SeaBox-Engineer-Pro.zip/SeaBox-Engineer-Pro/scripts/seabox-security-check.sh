#!/bin/bash
TOKEN="seabox-agent-2026"
API="http://localhost/api/agent.php"
WRITABLE=$(find /var/www/html -perm -o+w -type f 2>/dev/null | wc -l)
FAILED=$(grep "Failed password" /var/log/auth.log 2>/dev/null | tail -24 | wc -l)
if [ "$WRITABLE" -gt 0 ]; then
    /home/cboxms0/telegram-notify.sh "🔒 *تنبيه أمني*\n\nملفات قابلة للكتابة: $WRITABLE"
fi
if [ "$FAILED" -gt 10 ]; then
    /home/cboxms0/telegram-notify.sh "🔒 *تنبيه أمني*\n\nمحاولات دخول فاشلة: $FAILED"
fi
echo "$(date): Security check completed" >> /home/cboxms0/seabox-security.log
