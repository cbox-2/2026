#!/bin/bash
TOKEN="seabox-agent-2026"
API="http://localhost/api/agent.php"
USERS=$(mysql -u seabox_agent -p'SeaBox2026!Secure' nexusbox_db -N -e "SELECT COUNT(*) FROM users")
MESSAGES=$(mysql -u seabox_agent -p'SeaBox2026!Secure' nexusbox_db -N -e "SELECT COUNT(*) FROM messages")
ALERTS=$(mysql -u seabox_agent -p'SeaBox2026!Secure' nexusbox_db -N -e "SELECT COUNT(*) FROM system_alerts")
REPORT="{\"users\":$USERS,\"messages\":$MESSAGES,\"alerts\":$ALERTS}"
mysql -u seabox_agent -p'SeaBox2026!Secure' nexusbox_db -e "INSERT INTO system_reports (report_type, report_data) VALUES ('daily', '$REPORT')"
curl -s "$API?action=execute&tool=alert-system&args=%7B%22type%22%3A%22daily_report%22%2C%22severity%22%3A%22info%22%2C%22message%22%3A%22تقرير%20يومي%20مكتمل%22%7D&approved=true&token=$TOKEN" > /dev/null
echo "$(date): Daily report generated" >> /home/cboxms0/seabox-report.log
